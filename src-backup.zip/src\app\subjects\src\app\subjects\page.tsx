"use client";
import Link from "next/link";

export default function SubjectsPage(){
const data=[
{name:"اللغة العربية",teachers:4,classes:8},
{name:"الرياضيات",teachers:3,classes:6},
{name:"العلوم",teachers:2,classes:4},
];
return(
<main style={{padding:24,direction:"rtl",fontFamily:"Tahoma",background:"#f5f7fb",minHeight:"100vh"}}>
<div style={{maxWidth:1000,margin:"auto"}}>
<div style={{display:"flex",justifyContent:"space-between"}}>
<h1>إدارة المواد الدراسية</h1>
<Link href="/dashboard">العودة</Link>
</div>
<table style={{width:"100%",marginTop:20,background:"#fff",borderCollapse:"collapse"}}>
<thead><tr><th>المادة</th><th>عدد المعلمين</th><th>عدد الشعب</th></tr></thead>
<tbody>
{data.map((r,i)=><tr key={i}><td style={td}>{r.name}</td><td style={td}>{r.teachers}</td><td style={td}>{r.classes}</td></tr>)}
</tbody>
</table>
</div>
</main>
)}
const td={padding:"12px",borderBottom:"1px solid #e5e7eb",textAlign:"center"} as const;
