"use client";
import Link from "next/link";
export default function BackupPage(){
return(
<main style={{padding:24,direction:"rtl",fontFamily:"Tahoma",background:"#f4f7fb",minHeight:"100vh"}}>
<div style={{maxWidth:800,margin:"auto",background:"#fff",padding:24,borderRadius:16}}>
<h1>النسخ الاحتياطي والمزامنة</h1>
<p>إنشاء نسخة احتياطية واستعادة بيانات النظام.</p>
<div style={{display:"flex",gap:12,marginTop:20}}>
<button style={{padding:"12px 18px",background:"#2563eb",color:"#fff",border:"none",borderRadius:12}}>إنشاء نسخة احتياطية</button>
<button style={{padding:"12px 18px",background:"#16a34a",color:"#fff",border:"none",borderRadius:12}}>استعادة نسخة</button>
</div>
<div style={{marginTop:24}}>
<Link href="/dashboard">العودة</Link>
</div>
</div>
</main>
)}
