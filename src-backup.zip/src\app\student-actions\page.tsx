"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  type StudentRecord,
  type StudentActionRecord,
  type StudentActionType,
  getSession,
  getStudents,
  getStudentActions,
  saveStudentAction,
  updateStudentActionStatus,
} from "@/lib/appData";

const actionLabels: Record<StudentActionType, string> = {
  summon: "استدعاء",
  permission: "استئذان",
  entry: "دخول",
};

const actionColors: Record<StudentActionType, string> = {
  summon: "#dc2626",
  permission: "#2563eb",
  entry: "#16a34a",
};

const emptyForm = {
  studentId: "",
  type: "summon" as StudentActionType,
  reason: "",
  lesson: "الحصة الأولى",
  teacher: "",
  requester: "",
  note: "",
};

export default function StudentActionsPage() {
  const router = useRouter();

  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [actions, setActions] = useState<StudentActionRecord[]>([]);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = getSession();

    if (!session) {
      router.replace("/login");
      return;
    }

    setForm((prev) => ({ ...prev, requester: session.name }));
  }, [router]);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [studentData, actionData] = await Promise.all([
        getStudents(),
        getStudentActions(),
      ]);
      setStudents(studentData);
      setActions(actionData);
      setLoading(false);
    }

    load();
  }, []);

  const filteredStudents = useMemo(() => {
    const q = search.trim();

    if (!q) return students;

    return students.filter(
      (student) =>
        student.name.includes(q) ||
        student.grade.includes(q) ||
        student.section.includes(q) ||
        student.entryCode.includes(q)
    );
  }, [students, search]);

  const selectedStudent = students.find((student) => student.id === form.studentId);

  function updateField(field: keyof typeof emptyForm, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function submitAction(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");

    if (!selectedStudent) {
      setMessage("يرجى اختيار الطالب.");
      return;
    }

    if (!form.reason.trim() || !form.lesson.trim() || !form.teacher.trim() || !form.requester.trim()) {
      setMessage("يرجى تعبئة جميع الحقول المطلوبة.");
      return;
    }

    const newAction: StudentActionRecord = {
      id: `action-${Date.now()}`,
      studentId: selectedStudent.id,
      studentName: selectedStudent.name,
      grade: selectedStudent.grade,
      section: selectedStudent.section,
      type: form.type,
      reason: form.reason.trim(),
      lesson: form.lesson.trim(),
      teacher: form.teacher.trim(),
      requester: form.requester.trim(),
      note: form.note.trim(),
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    const saved = await saveStudentAction(newAction);

    if (!saved) {
      setMessage("تعذر حفظ الإجراء في قاعدة البيانات.");
      return;
    }

    setActions((prev) => [saved, ...prev]);
    setForm((prev) => ({
      ...emptyForm,
      requester: prev.requester,
      lesson: prev.lesson,
    }));
    setSearch("");
    setMessage("تم إنشاء الإجراء وحفظه في قاعدة البيانات.");
  }

  async function changeStatus(id: string, status: StudentActionRecord["status"]) {
    await updateStudentActionStatus(id, status);

    setActions((prev) =>
      prev.map((action) => (action.id === id ? { ...action, status } : action))
    );
  }

  const stats = {
    total: actions.length,
    summon: actions.filter((action) => action.type === "summon").length,
    permission: actions.filter((action) => action.type === "permission").length,
    entry: actions.filter((action) => action.type === "entry").length,
  };

  return (
    <main style={styles.page}>
      <section style={styles.container}>
        <header style={styles.header}>
          <div>
            <p style={styles.path}>الرئيسية / إجراءات الطالب</p>
            <h1 style={styles.title}>إجراءات الطالب</h1>
            <p style={styles.subtitle}>
              إنشاء طلب استدعاء أو استئذان أو دخول وحفظه في قاعدة البيانات.
            </p>
          </div>

          <Link href="/dashboard" style={styles.back}>
            العودة
          </Link>
        </header>

        <section style={styles.stats}>
          <Card title="إجمالي الإجراءات" value={stats.total} color="#2563eb" />
          <Card title="استدعاء" value={stats.summon} color="#dc2626" />
          <Card title="استئذان" value={stats.permission} color="#2563eb" />
          <Card title="دخول" value={stats.entry} color="#16a34a" />
        </section>

        <section style={styles.formCard}>
          <h2 style={styles.sectionTitle}>إنشاء إجراء جديد</h2>

          <form onSubmit={submitAction} style={styles.formGrid}>
            <div style={styles.full}>
              <label style={styles.label}>بحث عن الطالب</label>
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="ابحث بالاسم أو الصف أو الشعبة"
                style={styles.input}
              />
            </div>

            <div style={styles.full}>
              <label style={styles.label}>اختيار الطالب</label>
              <select
                value={form.studentId}
                onChange={(event) => updateField("studentId", event.target.value)}
                style={styles.input}
              >
                <option value="">اختر الطالب</option>
                {filteredStudents.map((student) => (
                  <option key={student.id} value={student.id}>
                    {student.name} - {student.grade} - {student.section}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={styles.label}>نوع الإجراء</label>
              <select
                value={form.type}
                onChange={(event) =>
                  updateField("type", event.target.value as StudentActionType)
                }
                style={styles.input}
              >
                <option value="summon">استدعاء</option>
                <option value="permission">استئذان</option>
                <option value="entry">دخول</option>
              </select>
            </div>

            <div>
              <label style={styles.label}>الحصة</label>
              <input
                value={form.lesson}
                onChange={(event) => updateField("lesson", event.target.value)}
                style={styles.input}
              />
            </div>

            <div>
              <label style={styles.label}>اسم المعلم</label>
              <input
                value={form.teacher}
                onChange={(event) => updateField("teacher", event.target.value)}
                placeholder="أ. اسم المعلم"
                style={styles.input}
              />
            </div>

            <div>
              <label style={styles.label}>مقدم الطلب</label>
              <input
                value={form.requester}
                onChange={(event) => updateField("requester", event.target.value)}
                placeholder="اسم الوكيل أو الإداري"
                style={styles.input}
              />
            </div>

            <div style={styles.full}>
              <label style={styles.label}>السبب</label>
              <input
                value={form.reason}
                onChange={(event) => updateField("reason", event.target.value)}
                placeholder="اكتب سبب الإجراء"
                style={styles.input}
              />
            </div>

            <div style={styles.full}>
              <label style={styles.label}>ملاحظات</label>
              <textarea
                value={form.note}
                onChange={(event) => updateField("note", event.target.value)}
                placeholder="ملاحظات إضافية"
                style={{ ...styles.input, minHeight: 90, resize: "vertical" }}
              />
            </div>

            <button type="submit" style={styles.submit}>
              حفظ الإجراء
            </button>
          </form>

          {message ? <p style={message.includes("تعذر") || message.includes("يرجى") ? styles.error : styles.message}>{message}</p> : null}
        </section>

        <section style={styles.listCard}>
          <div style={styles.listHeader}>
            <h2 style={styles.sectionTitle}>سجل الإجراءات</h2>
            <span style={styles.count}>{actions.length} إجراء</span>
          </div>

          {loading ? (
            <div style={styles.empty}>جارٍ تحميل الإجراءات...</div>
          ) : actions.length === 0 ? (
            <div style={styles.empty}>لا توجد إجراءات حتى الآن.</div>
          ) : (
            <div style={styles.cardsGrid}>
              {actions.map((action) => (
                <article key={action.id} style={styles.actionCard}>
                  <div style={styles.cardTop}>
                    <span
                      style={{
                        ...styles.typeBadge,
                        background: actionColors[action.type],
                      }}
                    >
                      {actionLabels[action.type]}
                    </span>

                    <span style={styles.statusBadge}>
                      {action.status === "pending"
                        ? "معلق"
                        : action.status === "done"
                          ? "تم التنفيذ"
                          : "مؤجل"}
                    </span>
                  </div>

                  <h3 style={styles.studentName}>{action.studentName}</h3>
                  <p style={styles.meta}>
                    {action.grade} - {action.section} • {action.lesson}
                  </p>

                  <div style={styles.infoBox}>
                    <p style={styles.infoText}>
                      <b>السبب:</b> {action.reason}
                    </p>
                    <p style={styles.infoText}>
                      <b>المعلم:</b> {action.teacher}
                    </p>
                    <p style={styles.infoText}>
                      <b>مقدم الطلب:</b> {action.requester}
                    </p>
                    {action.note ? (
                      <p style={styles.infoText}>
                        <b>ملاحظة:</b> {action.note}
                      </p>
                    ) : null}
                  </div>

                  <div style={styles.statusRow}>
                    <button
                      onClick={() => changeStatus(action.id, "done")}
                      style={{
                        ...styles.smallButton,
                        background: action.status === "done" ? "#16a34a" : "#f1f5f9",
                        color: action.status === "done" ? "#fff" : "#334155",
                      }}
                    >
                      تم التنفيذ
                    </button>

                    <button
                      onClick={() => changeStatus(action.id, "delayed")}
                      style={{
                        ...styles.smallButton,
                        background: action.status === "delayed" ? "#f59e0b" : "#f1f5f9",
                        color: action.status === "delayed" ? "#fff" : "#334155",
                      }}
                    >
                      تأجيل
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </section>
    </main>
  );
}

function Card({ title, value, color }: { title: string; value: number; color: string }) {
  return (
    <div style={styles.card}>
      <div style={{ ...styles.cardValue, color }}>{value}</div>
      <div style={styles.cardTitle}>{title}</div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#f4f7fb", direction: "rtl", padding: 24, fontFamily: "Tahoma, Arial, sans-serif", color: "#0f172a" },
  container: { maxWidth: 1180, margin: "0 auto" },
  header: { display: "flex", justifyContent: "space-between", gap: 16, marginBottom: 18 },
  path: { margin: 0, color: "#64748b", fontSize: 13 },
  title: { margin: "6px 0", fontSize: 32, fontWeight: 900 },
  subtitle: { margin: 0, color: "#64748b" },
  back: { background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: "12px 18px", color: "#0f172a", textDecoration: "none", fontWeight: 800, height: "fit-content" },
  stats: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: 16 },
  card: { background: "#fff", borderRadius: 18, padding: 16, textAlign: "center", border: "1px solid #e5e7eb", boxShadow: "0 10px 24px rgba(15,23,42,0.06)" },
  cardValue: { fontSize: 30, fontWeight: 900 },
  cardTitle: { color: "#64748b", marginTop: 4, fontSize: 13 },
  formCard: { background: "#fff", borderRadius: 22, padding: 18, marginBottom: 16, border: "1px solid #e5e7eb", boxShadow: "0 10px 24px rgba(15,23,42,0.06)" },
  sectionTitle: { margin: 0, fontSize: 20, fontWeight: 900 },
  formGrid: { marginTop: 14, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12, alignItems: "end" },
  full: { gridColumn: "1 / -1" },
  label: { display: "block", marginBottom: 6, fontSize: 13, color: "#334155", fontWeight: 800 },
  input: { width: "100%", boxSizing: "border-box", padding: "12px 14px", borderRadius: 14, border: "1px solid #cbd5e1", color: "#111827", background: "#fff", fontSize: 14, outline: "none" },
  submit: { border: "none", borderRadius: 14, background: "linear-gradient(90deg, #0f766e, #2563eb)", color: "#fff", padding: "12px 16px", cursor: "pointer", fontWeight: 900 },
  message: { margin: "12px 0 0", color: "#0f766e", fontWeight: 800, fontSize: 13 },
  error: { margin: "12px 0 0", color: "#dc2626", fontWeight: 800, fontSize: 13 },
  listCard: { background: "#fff", borderRadius: 22, border: "1px solid #e5e7eb", overflow: "hidden" },
  listHeader: { padding: 18, borderBottom: "1px solid #e5e7eb", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" },
  count: { background: "#e0f2fe", color: "#0369a1", padding: "7px 12px", borderRadius: 999, fontWeight: 900, fontSize: 12 },
  empty: { padding: 28, textAlign: "center", color: "#64748b" },
  cardsGrid: { padding: 18, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 12 },
  actionCard: { border: "1px solid #e5e7eb", borderRadius: 18, padding: 14, background: "#fbfdff" },
  cardTop: { display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center" },
  typeBadge: { color: "#fff", padding: "7px 12px", borderRadius: 999, fontSize: 12, fontWeight: 900 },
  statusBadge: { background: "#f1f5f9", color: "#334155", padding: "7px 12px", borderRadius: 999, fontSize: 12, fontWeight: 900 },
  studentName: { margin: "14px 0 4px", fontSize: 18, fontWeight: 900 },
  meta: { margin: 0, color: "#64748b", fontSize: 13 },
  infoBox: { marginTop: 12, background: "#f8fafc", borderRadius: 14, padding: 12 },
  infoText: { margin: "6px 0", fontSize: 13, color: "#334155", lineHeight: 1.7 },
  statusRow: { display: "flex", gap: 8, marginTop: 12 },
  smallButton: { border: "none", borderRadius: 10, padding: "9px 12px", cursor: "pointer", fontWeight: 900, flex: 1 },
};
