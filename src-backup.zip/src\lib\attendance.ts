import { supabase } from "@/lib/supabase";

export type AttendanceStatus =
  | "present"
  | "absent"
  | "late"
  | "excused";

export interface AttendanceRecord {
  id?: string;

  student_id: string;
  student_name: string;

  grade: string;
  section: string;

  teacher_id: string;
  teacher_name: string;

  date: string;
  lesson: string;

  status: AttendanceStatus;

  attendance_time?: string;

  created_at?: string;
  updated_at?: string;
}

export async function getAttendance(
  date: string,
  lesson: string
) {
  const { data, error } = await supabase
    .from("attendance_records")
    .select("*")
    .eq("date", date)
    .eq("lesson", lesson);

  if (error) throw error;

  return data ?? [];
}

export async function saveAttendance(
  records: AttendanceRecord[]
) {
  const { error } = await supabase
    .from("attendance_records")
    .upsert(records, {
      onConflict: "student_id,date,lesson",
    });

  if (error) throw error;

  return true;
}

export async function getStudentAttendance(
  studentId: string
) {
  const { data, error } = await supabase
    .from("attendance_records")
    .select("*")
    .eq("student_id", studentId)
    .order("date", {
      ascending: false,
    });

  if (error) throw error;

  return data ?? [];
}

export async function deleteAttendance(
  id: string
) {
  const { error } = await supabase
    .from("attendance_records")
    .delete()
    .eq("id", id);

  if (error) throw error;
}