﻿"use client";

import { useMemo, useState } from "react";
import {
  AlertTriangle,
  CalendarCheck,
  CheckCircle2,
  Clock3,
  Copy,
  Download,
  FileDown,
  RefreshCw,
  Save,
  Search,
  Send,
  UserCheck,
  UserMinus,
  Users,
} from "lucide-react";

type AttendanceStatus = "present" | "absent" | "late" | "excused";

type Student = {
  id: number;
  nationalId: string;
  name: string;
  status: AttendanceStatus;
  time: string;
  note: string;
};

const statusLabels: Record<AttendanceStatus, string> = {
  present: "حاضر",
  absent: "غائب",
  late: "متأخر",
  excused: "مستأذن",
};

const statusClasses: Record<AttendanceStatus, string> = {
  present: "bg-green-100 text-green-700 border-green-200",
  absent: "bg-red-100 text-red-700 border-red-200",
  late: "bg-yellow-100 text-yellow-700 border-yellow-200",
  excused: "bg-blue-100 text-blue-700 border-blue-200",
};

const initialStudents: Student[] = [
  {
    id: 1,
    nationalId: "1098745632",
    name: "باسل فهد الحربي",
    status: "present",
    time: "07:35",
    note: "",
  },
  {
    id: 2,
    nationalId: "1087654321",
    name: "خالد أحمد الحربي",
    status: "absent",
    time: "07:36",
    note: "لم يحضر",
  },
  {
    id: 3,
    nationalId: "1076543210",
    name: "سعد محمد الجهني",
    status: "late",
    time: "07:42",
    note: "تأخر 7 دقائق",
  },
  {
    id: 4,
    nationalId: "1065432109",
    name: "ريان سامي البلوي",
    status: "present",
    time: "07:34",
    note: "",
  },
  {
    id: 5,
    nationalId: "1054321098",
    name: "يزيد عبدالله العوفي",
    status: "excused",
    time: "07:39",
    note: "استئذان من الإدارة",
  },
];

export default function AttendancePage() {
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | AttendanceStatus>("all");

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const matchesSearch =
        student.name.includes(search) ||
        student.nationalId.includes(search) ||
        student.note.includes(search);

      const matchesStatus =
        statusFilter === "all" || student.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [students, search, statusFilter]);

  const counts = useMemo(() => {
    return {
      total: students.length,
      present: students.filter((s) => s.status === "present").length,
      absent: students.filter((s) => s.status === "absent").length,
      late: students.filter((s) => s.status === "late").length,
      excused: students.filter((s) => s.status === "excused").length,
    };
  }, [students]);

  function updateStatus(id: number, status: AttendanceStatus) {
    const now = new Date();
    const time = `${String(now.getHours()).padStart(2, "0")}:${String(
      now.getMinutes()
    ).padStart(2, "0")}`;

    setStudents((prev) =>
      prev.map((student) =>
        student.id === id
          ? {
              ...student,
              status,
              time,
            }
          : student
      )
    );
  }

  function updateNote(id: number, note: string) {
    setStudents((prev) =>
      prev.map((student) => (student.id === id ? { ...student, note } : student))
    );
  }

  function markAllPresent() {
    const now = new Date();
    const time = `${String(now.getHours()).padStart(2, "0")}:${String(
      now.getMinutes()
    ).padStart(2, "0")}`;

    setStudents((prev) =>
      prev.map((student) => ({
        ...student,
        status: "present",
        time,
        note: student.note,
      }))
    );
  }

  function copyPreviousPeriod() {
    setStudents([
      {
        id: 1,
        nationalId: "1098745632",
        name: "باسل فهد الحربي",
        status: "present",
        time: "08:20",
        note: "",
      },
      {
        id: 2,
        nationalId: "1087654321",
        name: "خالد أحمد الحربي",
        status: "absent",
        time: "08:21",
        note: "منسوخ من الحصة السابقة",
      },
      {
        id: 3,
        nationalId: "1076543210",
        name: "سعد محمد الجهني",
        status: "late",
        time: "08:23",
        note: "منسوخ من الحصة السابقة",
      },
      {
        id: 4,
        nationalId: "1065432109",
        name: "ريان سامي البلوي",
        status: "present",
        time: "08:20",
        note: "",
      },
      {
        id: 5,
        nationalId: "1054321098",
        name: "يزيد عبدالله العوفي",
        status: "excused",
        time: "08:25",
        note: "استئذان من الإدارة",
      },
    ]);
  }

  function updateAbsenceOnly() {
    setStudents((prev) =>
      prev.map((student) =>
        student.status === "absent"
          ? {
              ...student,
              note: student.note || "تم تحديث الغياب فقط",
            }
          : student
      )
    );
  }

  return (
    <section className="px-4 py-5">
      <div className="mx-auto max-w-7xl space-y-5">
        <header className="rounded-3xl bg-gradient-to-l from-blue-800 to-blue-600 p-5 text-white shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-sm text-blue-100">تحضير الحصص</p>
              <h1 className="mt-1 text-2xl font-black text-white md:text-3xl">
                تحضير الطلاب للحصة الحالية
              </h1>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-blue-100">
                تسجيل الحضور والغياب والتأخر والاستئذان، ثم حفظ التحضير أو إرساله للوكيل.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:flex">
              <button className="rounded-2xl bg-white px-4 py-3 text-sm font-bold text-blue-700">
                حفظ التحضير
              </button>
              <button className="rounded-2xl bg-blue-950/40 px-4 py-3 text-sm font-bold text-white">
                إرسال للوكيل
              </button>
            </div>
          </div>
        </header>

        <section className="rounded-3xl bg-white p-4 shadow-sm border border-slate-100">
          <div className="grid gap-3 md:grid-cols-3 xl:grid-cols-6">
            <Info title="التاريخ" value="2026-06-25" />
            <Info title="اليوم" value="الخميس" />
            <Info title="الحصة" value="الحصة الثانية" />
            <Info title="الصف / الشعبة" value="الأول الثانوي / أ" />
            <Info title="المادة" value="الرياضيات" />
            <Info title="المعلم" value="أ. عبدالله الحربي" />
          </div>
        </section>

        <section className="grid grid-cols-2 gap-3 md:grid-cols-5">
          <Stat title="الإجمالي" value={counts.total} icon={<Users size={22} />} />
          <Stat title="حاضر" value={counts.present} icon={<UserCheck size={22} />} />
          <Stat title="غائب" value={counts.absent} icon={<UserMinus size={22} />} />
          <Stat title="متأخر" value={counts.late} icon={<Clock3 size={22} />} />
          <Stat title="مستأذن" value={counts.excused} icon={<CheckCircle2 size={22} />} />
        </section>

        <section className="grid gap-3 md:grid-cols-3">
          <QuickButton
            title="اعتبار الجميع حاضرين"
            description="تسجيل جميع الطلاب حاضرون فورًا"
            icon={<UserCheck size={22} />}
            onClick={markAllPresent}
          />
          <QuickButton
            title="نسخ من الحصة السابقة"
            description="استيراد آخر حالة حضور لنفس الشعبة"
            icon={<Copy size={22} />}
            onClick={copyPreviousPeriod}
          />
          <QuickButton
            title="تحديث الغياب فقط"
            description="الإبقاء على الحالات وتحديث الغياب"
            icon={<RefreshCw size={22} />}
            onClick={updateAbsenceOnly}
          />
        </section>

        <section className="rounded-3xl bg-white p-4 shadow-sm border border-slate-100">
          <div className="grid gap-3 md:grid-cols-5">
            <div className="relative md:col-span-2">
              <Search
                size={18}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="ابحث بالاسم، الهوية، الملاحظة"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-3 pr-10 pl-3 text-sm outline-none focus:border-blue-500"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value as "all" | AttendanceStatus)}
              className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm outline-none focus:border-blue-500"
            >
              <option value="all">كل الحالات</option>
              <option value="present">حاضر</option>
              <option value="absent">غائب</option>
              <option value="late">متأخر</option>
              <option value="excused">مستأذن</option>
            </select>

            <button className="flex items-center justify-center gap-2 rounded-2xl bg-slate-100 px-4 py-3 text-sm font-bold text-slate-700">
              <FileDown size={18} />
              Excel
            </button>

            <button className="flex items-center justify-center gap-2 rounded-2xl bg-slate-100 px-4 py-3 text-sm font-bold text-slate-700">
              <Download size={18} />
              PDF
            </button>
          </div>
        </section>

        <section className="hidden overflow-hidden rounded-3xl bg-white shadow-sm border border-slate-100 xl:block">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="p-4">#</th>
                <th className="p-4">الهوية الوطنية</th>
                <th className="p-4">اسم الطالب</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">وقت التسجيل</th>
                <th className="p-4">ملاحظات</th>
              </tr>
            </thead>

            <tbody>
              {filteredStudents.map((student, index) => (
                <tr key={student.id} className="border-t border-slate-100">
                  <td className="p-4 font-bold">{index + 1}</td>
                  <td className="p-4 text-slate-600">{student.nationalId}</td>
                  <td className="p-4 font-bold text-slate-900">{student.name}</td>
                  <td className="p-4">
                    <StatusSelector
                      value={student.status}
                      onChange={(status) => updateStatus(student.id, status)}
                    />
                  </td>
                  <td className="p-4 text-slate-600">{student.time}</td>
                  <td className="p-4">
                    <input
                      value={student.note}
                      onChange={(event) => updateNote(student.id, event.target.value)}
                      placeholder="ملاحظة"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="space-y-3 xl:hidden">
          {filteredStudents.map((student) => (
            <article
              key={student.id}
              className="rounded-3xl bg-white p-4 shadow-sm border border-slate-100"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-bold text-slate-900">{student.name}</h2>
                  <p className="mt-1 text-xs text-slate-500">
                    الهوية: {student.nationalId}
                  </p>
                </div>
                <span className={`rounded-full border px-3 py-1 text-xs font-bold ${statusClasses[student.status]}`}>
                  {statusLabels[student.status]}
                </span>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                {(Object.keys(statusLabels) as AttendanceStatus[]).map((status) => (
                  <button
                    key={status}
                    onClick={() => updateStatus(student.id, status)}
                    className={`rounded-2xl border px-3 py-3 text-sm font-bold ${
                      student.status === status
                        ? statusClasses[status]
                        : "border-slate-200 bg-slate-50 text-slate-600"
                    }`}
                  >
                    {statusLabels[status]}
                  </button>
                ))}
              </div>

              <div className="mt-4 grid gap-3 rounded-2xl bg-slate-50 p-3">
                <Info title="وقت التسجيل" value={student.time} />
                <input
                  value={student.note}
                  onChange={(event) => updateNote(student.id, event.target.value)}
                  placeholder="ملاحظة"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-blue-500"
                />
              </div>
            </article>
          ))}
        </section>

        {filteredStudents.length === 0 && (
          <section className="rounded-3xl bg-white p-8 text-center shadow-sm border border-slate-100">
            <AlertTriangle className="mx-auto text-yellow-600" size={28} />
            <p className="mt-3 font-bold text-slate-500">لا توجد نتائج مطابقة.</p>
          </section>
        )}

        <section className="grid gap-3 md:grid-cols-3">
          <button className="flex items-center justify-center gap-2 rounded-2xl bg-blue-700 px-4 py-3 text-sm font-bold text-white">
            <Save size={18} />
            حفظ التحضير
          </button>

          <button className="flex items-center justify-center gap-2 rounded-2xl bg-green-700 px-4 py-3 text-sm font-bold text-white">
            <Send size={18} />
            إرسال للوكيل / الإداري
          </button>

          <button className="flex items-center justify-center gap-2 rounded-2xl bg-slate-800 px-4 py-3 text-sm font-bold text-white">
            <CalendarCheck size={18} />
            اعتماد الحصة
          </button>
        </section>
      </div>
    </section>
  );
}

function Info({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-3">
      <p className="text-xs text-slate-500">{title}</p>
      <h3 className="mt-1 font-bold text-slate-900">{value}</h3>
    </div>
  );
}

function Stat({
  title,
  value,
  icon,
}: {
  title: string;
  value: number;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-3xl bg-white p-4 shadow-sm border border-slate-100">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm text-slate-500">{title}</p>
          <h3 className="mt-1 text-3xl font-black text-slate-900">{value}</h3>
        </div>

        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-700">
          {icon}
        </div>
      </div>
    </div>
  );
}

function QuickButton({
  title,
  description,
  icon,
  onClick,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="rounded-3xl bg-white p-4 text-right shadow-sm border border-slate-100 transition hover:bg-blue-50"
    >
      <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-700">
        {icon}
      </div>
      <h3 className="font-bold text-slate-900">{title}</h3>
      <p className="mt-1 text-sm text-slate-500">{description}</p>
    </button>
  );
}

function StatusSelector({
  value,
  onChange,
}: {
  value: AttendanceStatus;
  onChange: (status: AttendanceStatus) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {(Object.keys(statusLabels) as AttendanceStatus[]).map((status) => (
        <button
          key={status}
          onClick={() => onChange(status)}
          className={`rounded-xl border px-3 py-2 text-xs font-bold ${
            value === status
              ? statusClasses[status]
              : "border-slate-200 bg-slate-50 text-slate-600"
          }`}
        >
          {statusLabels[status]}
        </button>
      ))}
    </div>
  );
}
