"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { type StudentRecord, getSession, getStudents, saveStudents } from "@/lib/appData";

type StudentForm = { name: string; grade: string; section: string; entryCode: string };
const emptyForm: StudentForm = { name: "", grade: "", section: "", entryCode: "" };

export default function StudentsPage() {
  const router = useRouter();
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [sectionFilter, setSectionFilter] = useState("all");
  const [form, setForm] = useState<StudentForm>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = getSession();
    if (!session) router.replace("/login");
  }, [router]);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setStudents(await getStudents());
      setLoading(false);
    }
    load();
  }, []);

  const grades = useMemo(() => Array.from(new Set(students.map((s) => s.grade))).filter(Boolean), [students]);
  const sections = useMemo(() => Array.from(new Set(students.map((s) => s.section))).filter(Boolean), [students]);

  const filteredStudents = useMemo(() => {
    const q = search.trim();
    return students.filter((s) => {
      const matchesSearch = !q || s.name.includes(q) || s.grade.includes(q) || s.section.includes(q) || s.entryCode.includes(q);
      const matchesGrade = gradeFilter === "all" || s.grade === gradeFilter;
      const matchesSection = sectionFilter === "all" || s.section === sectionFilter;
      return matchesSearch && matchesGrade && matchesSection;
    });
  }, [students, search, gradeFilter, sectionFilter]);

  function updateField(field: keyof StudentForm, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");

    if (!form.name.trim() || !form.grade.trim() || !form.section.trim() || !form.entryCode.trim()) {
      setMessage("يرجى تعبئة جميع الحقول.");
      return;
    }

    let next: StudentRecord[];

    if (editingId) {
      next = students.map((student) =>
        student.id === editingId
          ? { ...student, name: form.name.trim(), grade: form.grade.trim(), section: form.section.trim(), entryCode: form.entryCode.trim() }
          : student
      );
      setMessage("تم تعديل بيانات الطالب.");
    } else {
      next = [...students, {
        id: `student-${Date.now()}`,
        name: form.name.trim(),
        grade: form.grade.trim(),
        section: form.section.trim(),
        entryCode: form.entryCode.trim(),
      }];
      setMessage("تمت إضافة الطالب.");
    }

    setStudents(next);
    await saveStudents(next);
    setForm(emptyForm);
    setEditingId(null);
  }

  function startEdit(student: StudentRecord) {
    setEditingId(student.id);
    setForm({ name: student.name, grade: student.grade, section: student.section, entryCode: student.entryCode });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function deleteStudent(id: string) {
    if (!confirm("هل تريد حذف الطالب؟")) return;
    const next = students.filter((student) => student.id !== id);
    setStudents(next);
    await saveStudents(next);
    setMessage("تم حذف الطالب من القائمة الحالية.");
  }

  const stats = {
    total: students.length,
    grades: grades.length,
    sections: sections.length,
    firstGrade: students.filter((s) => s.grade.includes("الأول")).length,
  };

  return (
    <main style={styles.page}>
      <section style={styles.container}>
        <header style={styles.header}>
          <div>
            <p style={styles.path}>الرئيسية / إدارة المدرسة / الطلاب</p>
            <h1 style={styles.title}>إدارة الطلاب</h1>
            <p style={styles.subtitle}>إضافة الطلاب وتعديل بياناتهم ونقلهم بين الصفوف والشعب.</p>
          </div>
          <Link href="/dashboard" style={styles.back}>العودة</Link>
        </header>

        <section style={styles.stats}>
          <Card title="إجمالي الطلاب" value={stats.total} color="#2563eb" />
          <Card title="عدد الصفوف" value={stats.grades} color="#16a34a" />
          <Card title="عدد الشعب" value={stats.sections} color="#f59e0b" />
          <Card title="الأول الثانوي" value={stats.firstGrade} color="#7c3aed" />
        </section>

        <section style={styles.formCard}>
          <div style={styles.formHeader}>
            <h2 style={styles.sectionTitle}>{editingId ? "تعديل بيانات الطالب" : "إضافة طالب جديد"}</h2>
            {editingId ? <button type="button" onClick={() => { setEditingId(null); setForm(emptyForm); }} style={styles.cancelButton}>إلغاء التعديل</button> : null}
          </div>

          <form onSubmit={handleSubmit} style={styles.formGrid}>
            <Field label="اسم الطالب"><input value={form.name} onChange={(e) => updateField("name", e.target.value)} placeholder="مثال: طلال الجهني" style={styles.input} /></Field>
            <Field label="الصف">
              <select value={form.grade} onChange={(e) => updateField("grade", e.target.value)} style={styles.input}>
                <option value="">اختر الصف</option>
                <option value="الأول الثانوي">الأول الثانوي</option>
                <option value="الثاني الثانوي">الثاني الثانوي</option>
                <option value="الثالث الثانوي">الثالث الثانوي</option>
              </select>
            </Field>
            <Field label="الشعبة"><input value={form.section} onChange={(e) => updateField("section", e.target.value)} placeholder="مثال: أ" style={styles.input} /></Field>
            <Field label="رمز الدخول"><input value={form.entryCode} onChange={(e) => updateField("entryCode", e.target.value)} placeholder="مثال: 1234" style={styles.input} /></Field>
            <button type="submit" style={styles.submitButton}>{editingId ? "حفظ التعديل" : "إضافة الطالب"}</button>
          </form>

          {message ? <p style={message.includes("يرجى") ? styles.error : styles.message}>{message}</p> : null}
        </section>

        <section style={styles.filters}>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث باسم الطالب أو الصف أو الشعبة أو رمز الدخول" style={styles.input} />
          <select value={gradeFilter} onChange={(e) => setGradeFilter(e.target.value)} style={styles.select}>
            <option value="all">كل الصفوف</option>
            {grades.map((grade) => <option key={grade} value={grade}>{grade}</option>)}
          </select>
          <select value={sectionFilter} onChange={(e) => setSectionFilter(e.target.value)} style={styles.select}>
            <option value="all">كل الشعب</option>
            {sections.map((section) => <option key={section} value={section}>{section}</option>)}
          </select>
        </section>

        <section style={styles.tableCard}>
          <div style={styles.tableHeader}>
            <h2 style={styles.sectionTitle}>قائمة الطلاب</h2>
            <span style={styles.count}>{filteredStudents.length} طالب</span>
          </div>

          {loading ? <div style={styles.empty}>جارٍ تحميل الطلاب...</div> : (
            <div style={styles.tableWrapper}>
              <table style={styles.table}>
                <thead>
                  <tr style={styles.headRow}>
                    <th style={styles.th}>#</th>
                    <th style={styles.th}>اسم الطالب</th>
                    <th style={styles.th}>الصف</th>
                    <th style={styles.th}>الشعبة</th>
                    <th style={styles.th}>رمز الدخول</th>
                    <th style={styles.th}>الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredStudents.map((student, index) => (
                    <tr key={student.id}>
                      <td style={styles.td}>{index + 1}</td>
                      <td style={{ ...styles.td, fontWeight: 900, color: "#000" }}>{student.name}</td>
                      <td style={styles.td}>{student.grade}</td>
                      <td style={styles.td}>{student.section}</td>
                      <td style={styles.td}>{student.entryCode}</td>
                      <td style={styles.td}>
                        <div style={styles.actions}>
                          <button onClick={() => startEdit(student)} style={styles.editButton}>تعديل</button>
                          <button onClick={() => deleteStudent(student.id)} style={styles.deleteButton}>حذف</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredStudents.length === 0 ? <div style={styles.empty}>لا يوجد طلاب مطابقون للبحث.</div> : null}
            </div>
          )}
        </section>
      </section>
    </main>
  );
}

function Card({ title, value, color }: { title: string; value: number; color: string }) {
  return (
    <div style={styles.card}>
      <div style={{ ...styles.cardValue, color }}>{value}</div>
      <div style={styles.cardTitle}>{title}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label style={styles.label}>{label}</label>
      {children}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#f4f7fb", direction: "rtl", padding: 24, fontFamily: "Tahoma, Arial, sans-serif", color: "#0f172a" },
  container: { maxWidth: 1180, margin: "0 auto" },
  header: { display: "flex", justifyContent: "space-between", gap: 16, marginBottom: 18 },
  path: { margin: 0, color: "#64748b", fontSize: 13 },
  title: { margin: "6px 0", fontSize: 32, fontWeight: 900 },
  subtitle: { margin: 0, color: "#64748b" },
  back: { background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: "12px 18px", color: "#0f172a", textDecoration: "none", fontWeight: 800, height: "fit-content" },
  stats: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: 16 },
  card: { background: "#fff", borderRadius: 18, padding: 16, textAlign: "center", border: "1px solid #e5e7eb", boxShadow: "0 10px 24px rgba(15,23,42,0.06)" },
  cardValue: { fontSize: 30, fontWeight: 900 },
  cardTitle: { color: "#64748b", marginTop: 4, fontSize: 13 },
  formCard: { background: "#fff", borderRadius: 22, padding: 18, marginBottom: 16, border: "1px solid #e5e7eb", boxShadow: "0 10px 24px rgba(15,23,42,0.06)" },
  formHeader: { display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", marginBottom: 14 },
  sectionTitle: { margin: 0, fontSize: 20, fontWeight: 900 },
  cancelButton: { border: "none", borderRadius: 12, background: "#f1f5f9", color: "#334155", padding: "10px 14px", cursor: "pointer", fontWeight: 800 },
  formGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12, alignItems: "end" },
  label: { display: "block", marginBottom: 6, fontSize: 13, color: "#334155", fontWeight: 800 },
  input: { width: "100%", boxSizing: "border-box", padding: "12px 14px", borderRadius: 14, border: "1px solid #cbd5e1", color: "#111827", background: "#fff", fontSize: 14, outline: "none" },
  select: { width: "100%", boxSizing: "border-box", padding: "12px 14px", borderRadius: 14, border: "1px solid #cbd5e1", color: "#111827", background: "#fff", fontSize: 14, outline: "none" },
  submitButton: { border: "none", borderRadius: 14, background: "linear-gradient(90deg, #0f766e, #2563eb)", color: "#fff", padding: "12px 16px", cursor: "pointer", fontWeight: 900 },
  message: { margin: "12px 0 0", color: "#0f766e", fontWeight: 800, fontSize: 13 },
  error: { margin: "12px 0 0", color: "#dc2626", fontWeight: 800, fontSize: 13 },
  filters: { background: "#fff", borderRadius: 20, padding: 16, display: "grid", gridTemplateColumns: "1fr 220px 220px", gap: 12, marginBottom: 16, border: "1px solid #e5e7eb" },
  tableCard: { background: "#fff", borderRadius: 22, border: "1px solid #e5e7eb", overflow: "hidden" },
  tableHeader: { padding: 18, borderBottom: "1px solid #e5e7eb", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" },
  count: { background: "#e0f2fe", color: "#0369a1", padding: "7px 12px", borderRadius: 999, fontWeight: 900, fontSize: 12 },
  tableWrapper: { overflowX: "auto" },
  table: { width: "100%", minWidth: 780, borderCollapse: "collapse" },
  headRow: { background: "#f0fdf4" },
  th: { padding: 14, color: "#14532d", fontWeight: 900, borderBottom: "1px solid #dcfce7", textAlign: "center" },
  td: { padding: 14, borderBottom: "1px solid #f1f5f9", textAlign: "center", color: "#111827" },
  actions: { display: "flex", justifyContent: "center", gap: 8, flexWrap: "wrap" },
  editButton: { border: "none", borderRadius: 10, padding: "8px 12px", background: "#2563eb", color: "#fff", cursor: "pointer", fontWeight: 900 },
  deleteButton: { border: "none", borderRadius: 10, padding: "8px 12px", background: "#dc2626", color: "#fff", cursor: "pointer", fontWeight: 900 },
  empty: { padding: 28, textAlign: "center", color: "#64748b" },
};
