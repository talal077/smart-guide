"use client";
import Link from "next/link";

const links=[
["لوحة التحكم","/dashboard"],
["التحضير","/attendance"],
["الطلاب","/students"],
["التقارير","/reports"],
["الإشعارات","/notifications"],
["الإعدادات","/settings"],
];

export default function NavigationPage(){
return(
<main style={{padding:24,direction:"rtl",fontFamily:"Tahoma",background:"#f4f7fb",minHeight:"100vh"}}>
<div style={{maxWidth:900,margin:"auto",background:"#fff",padding:24,borderRadius:16}}>
<h1>التنقل بين صفحات النظام</h1>
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:16,marginTop:20}}>
{links.map(([t,h])=>(
<Link key={h} href={h} style={{textDecoration:"none",background:"#2563eb",color:"#fff",padding:18,borderRadius:14,textAlign:"center",fontWeight:700}}>
{t}
</Link>
))}
</div>
</div>
</main>
)}
