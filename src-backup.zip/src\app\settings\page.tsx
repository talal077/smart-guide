"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { clearSession, getSession } from "@/lib/appData";

export default function SettingsPage() {
  const router = useRouter();

  const [school,setSchool]=useState("ثانوية الأمير عبدالمجيد بن عبدالعزيز");
  const [education,setEducation]=useState("إدارة تعليم المدينة المنورة");
  const [message,setMessage]=useState("");

  useEffect(()=>{
    const session=getSession();
    if(!session) router.replace("/login");
  },[router]);

  function saveSettings(){
    localStorage.setItem("school-name",school);
    localStorage.setItem("education-name",education);
    setMessage("تم حفظ الإعدادات.");
  }

  function logout(){
    clearSession();
    router.replace("/login");
  }

  return(
    <main style={{padding:24,direction:"rtl",background:"#f4f7fb",minHeight:"100vh",fontFamily:"Tahoma"}}>
      <div style={{maxWidth:900,margin:"0 auto"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <h1>الإعدادات</h1>
            <p>إعدادات النظام الأساسية.</p>
          </div>
          <Link href="/dashboard">العودة</Link>
        </div>

        <div style={{background:"#fff",padding:24,borderRadius:18,marginTop:24}}>
          <label>الإدارة التعليمية</label>
          <input value={education} onChange={e=>setEducation(e.target.value)} style={input}/>
          <label>اسم المدرسة</label>
          <input value={school} onChange={e=>setSchool(e.target.value)} style={input}/>

          <div style={{display:"flex",gap:12,marginTop:20}}>
            <button onClick={saveSettings} style={saveBtn}>حفظ</button>
            <button onClick={logout} style={logoutBtn}>تسجيل الخروج</button>
          </div>

          {message && <p style={{color:"#16a34a",marginTop:16,fontWeight:700}}>{message}</p>}
        </div>
      </div>
    </main>
  );
}

const input={
 width:"100%",
 padding:"12px",
 border:"1px solid #cbd5e1",
 borderRadius:"12px",
 marginTop:"6px",
 marginBottom:"16px",
 boxSizing:"border-box"
} as React.CSSProperties;

const saveBtn={
 background:"#2563eb",
 color:"#fff",
 border:"none",
 padding:"12px 18px",
 borderRadius:"12px",
 cursor:"pointer",
 fontWeight:700
} as React.CSSProperties;

const logoutBtn={
 background:"#dc2626",
 color:"#fff",
 border:"none",
 padding:"12px 18px",
 borderRadius:"12px",
 cursor:"pointer",
 fontWeight:700
} as React.CSSProperties;
