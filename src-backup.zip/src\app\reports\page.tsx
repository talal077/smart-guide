﻿"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  type AttendanceRecord,
  type StudentRecord,
  getAttendance,
  getSession,
  getStudents,
} from "@/lib/appData";

type PeriodFilter = "today" | "week" | "month" | "all";

const statusLabels: Record<AttendanceRecord["status"], string> = {
  present: "حاضر",
  absent: "غائب",
  late: "متأخر",
  excused: "مستأذن",
};

const statusColors: Record<AttendanceRecord["status"], string> = {
  present: "#16a34a",
  absent: "#dc2626",
  late: "#f59e0b",
  excused: "#2563eb",
};

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function daysAgo(days: number) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}

export default function ReportsPage() {
  const router = useRouter();

  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [period, setPeriod] = useState<PeriodFilter>("month");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [sectionFilter, setSectionFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = getSession();
    if (!session) router.replace("/login");
  }, [router]);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [studentData, attendanceData] = await Promise.all([
        getStudents(),
        getAttendance(),
      ]);
      setStudents(studentData);
      setRecords(attendanceData);
      setLoading(false);
    }

    load();
  }, []);

  const grades = useMemo(() => {
    return Array.from(new Set(students.map((student) => student.grade))).filter(Boolean);
  }, [students]);

  const sections = useMemo(() => {
    return Array.from(new Set(students.map((student) => student.section))).filter(Boolean);
  }, [students]);

  const filteredRecords = useMemo(() => {
    const today = todayIso();
    const weekStart = daysAgo(7);
    const monthStart = daysAgo(30);

    return records.filter((record) => {
      const periodOk =
        period === "all" ||
        (period === "today" && record.date === today) ||
        (period === "week" && record.date >= weekStart) ||
        (period === "month" && record.date >= monthStart);

      const gradeOk = gradeFilter === "all" || record.grade === gradeFilter;
      const sectionOk = sectionFilter === "all" || record.section === sectionFilter;

      return periodOk && gradeOk && sectionOk;
    });
  }, [records, period, gradeFilter, sectionFilter]);

  const stats = useMemo(() => {
    const total = filteredRecords.length;
    const present = filteredRecords.filter((record) => record.status === "present").length;
    const absent = filteredRecords.filter((record) => record.status === "absent").length;
    const late = filteredRecords.filter((record) => record.status === "late").length;
    const excused = filteredRecords.filter((record) => record.status === "excused").length;
    const attendanceRate = total ? Math.round((present / total) * 100) : 0;

    return { total, present, absent, late, excused, attendanceRate };
  }, [filteredRecords]);

  const studentSummary = useMemo(() => {
    const map = new Map<string, { name: string; grade: string; section: string; absent: number; late: number; present: number; total: number }>();

    for (const record of filteredRecords) {
      const current =
        map.get(record.studentId) ??
        {
          name: record.studentName,
          grade: record.grade,
          section: record.section,
          absent: 0,
          late: 0,
          present: 0,
          total: 0,
        };

      current.total += 1;
      if (record.status === "absent") current.absent += 1;
      if (record.status === "late") current.late += 1;
      if (record.status === "present") current.present += 1;

      map.set(record.studentId, current);
    }

    return Array.from(map.values()).sort((a, b) => b.absent + b.late - (a.absent + a.late));
  }, [filteredRecords]);

  const riskyStudents = studentSummary.slice(0, 8);
  const committedStudents = [...studentSummary]
    .filter((student) => student.total > 0)
    .sort((a, b) => b.present / b.total - a.present / a.total)
    .slice(0, 8);

  function exportExcel() {
    alert("تصدير Excel سيتم ربطه في المرحلة التالية.");
  }

  function exportPDF() {
    alert("تصدير PDF سيتم ربطه في المرحلة التالية.");
  }

  return (
    <main style={styles.page}>
      <section style={styles.container}>
        <header style={styles.header}>
          <div>
            <p style={styles.path}>الرئيسية / التقارير والإحصائيات</p>
            <h1 style={styles.title}>التقارير والإحصائيات</h1>
            <p style={styles.subtitle}>
              مؤشرات الحضور والغياب والتأخر والاستئذان حسب الفترة والصف والشعبة.
            </p>
          </div>

          <Link href="/dashboard" style={styles.back}>
            العودة
          </Link>
        </header>

        <section style={styles.filtersCard}>
          <div>
            <label style={styles.label}>الفترة</label>
            <select value={period} onChange={(e) => setPeriod(e.target.value as PeriodFilter)} style={styles.input}>
              <option value="today">اليوم</option>
              <option value="week">آخر 7 أيام</option>
              <option value="month">آخر 30 يومًا</option>
              <option value="all">كل السجلات</option>
            </select>
          </div>

          <div>
            <label style={styles.label}>الصف</label>
            <select value={gradeFilter} onChange={(e) => setGradeFilter(e.target.value)} style={styles.input}>
              <option value="all">كل الصفوف</option>
              {grades.map((grade) => (
                <option key={grade} value={grade}>{grade}</option>
              ))}
            </select>
          </div>

          <div>
            <label style={styles.label}>الشعبة</label>
            <select value={sectionFilter} onChange={(e) => setSectionFilter(e.target.value)} style={styles.input}>
              <option value="all">كل الشعب</option>
              {sections.map((section) => (
                <option key={section} value={section}>{section}</option>
              ))}
            </select>
          </div>

          <button onClick={exportExcel} style={{ ...styles.actionButton, background: "#16a34a" }}>تصدير Excel</button>
          <button onClick={exportPDF} style={{ ...styles.actionButton, background: "#0f172a" }}>تصدير PDF</button>
        </section>

        <section style={styles.stats}>
          <Card title="إجمالي السجلات" value={stats.total} color="#2563eb" />
          <Card title="الحاضرون" value={stats.present} color="#16a34a" />
          <Card title="الغائبون" value={stats.absent} color="#dc2626" />
          <Card title="المتأخرون" value={stats.late} color="#f59e0b" />
          <Card title="المستأذنون" value={stats.excused} color="#2563eb" />
          <Card title="نسبة الالتزام" value={`${stats.attendanceRate}%`} color="#0f766e" />
        </section>

        <section style={styles.grid2}>
          <div style={styles.panel}>
            <div style={styles.panelHeader}>
              <h2 style={styles.sectionTitle}>مؤشر الحالات</h2>
              <span style={styles.hint}>حسب الفترة المحددة</span>
            </div>

            <ChartBar label="حاضر" value={stats.present} total={stats.total} color="#16a34a" />
            <ChartBar label="غائب" value={stats.absent} total={stats.total} color="#dc2626" />
            <ChartBar label="متأخر" value={stats.late} total={stats.total} color="#f59e0b" />
            <ChartBar label="مستأذن" value={stats.excused} total={stats.total} color="#2563eb" />
          </div>

          <div style={styles.panel}>
            <div style={styles.panelHeader}>
              <h2 style={styles.sectionTitle}>مؤشر الخطورة</h2>
              <span style={styles.hint}>أكثر الطلاب غيابًا وتأخرًا</span>
            </div>

            {loading ? (
              <div style={styles.empty}>جارٍ تحميل البيانات...</div>
            ) : riskyStudents.length === 0 ? (
              <div style={styles.empty}>لا توجد بيانات كافية.</div>
            ) : (
              <div style={styles.list}>
                {riskyStudents.map((student) => (
                  <StudentLine
                    key={`${student.name}-${student.grade}-${student.section}`}
                    name={student.name}
                    desc={`${student.grade} - ${student.section}`}
                    value={`غياب ${student.absent} / تأخر ${student.late}`}
                    tone={student.absent >= 3 ? "danger" : "warning"}
                  />
                ))}
              </div>
            )}
          </div>
        </section>

        <section style={styles.grid2}>
          <div style={styles.panel}>
            <div style={styles.panelHeader}>
              <h2 style={styles.sectionTitle}>الأكثر التزامًا</h2>
              <span style={styles.hint}>حسب نسبة الحضور</span>
            </div>

            {committedStudents.length === 0 ? (
              <div style={styles.empty}>لا توجد بيانات كافية.</div>
            ) : (
              <div style={styles.list}>
                {committedStudents.map((student) => {
                  const rate = student.total ? Math.round((student.present / student.total) * 100) : 0;
                  return (
                    <StudentLine
                      key={`${student.name}-${student.grade}-${student.section}-ok`}
                      name={student.name}
                      desc={`${student.grade} - ${student.section}`}
                      value={`${rate}%`}
                      tone="success"
                    />
                  );
                })}
              </div>
            )}
          </div>

          <div style={styles.panel}>
            <div style={styles.panelHeader}>
              <h2 style={styles.sectionTitle}>آخر السجلات</h2>
              <span style={styles.hint}>{filteredRecords.length} سجل</span>
            </div>

            {filteredRecords.length === 0 ? (
              <div style={styles.empty}>لا توجد سجلات.</div>
            ) : (
              <div style={styles.tableWrapper}>
                <table style={styles.table}>
                  <thead>
                    <tr style={styles.headRow}>
                      <th style={styles.th}>الطالب</th>
                      <th style={styles.th}>الحصة</th>
                      <th style={styles.th}>التاريخ</th>
                      <th style={styles.th}>الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRecords.slice(0, 12).map((record) => (
                      <tr key={record.id}>
                        <td style={styles.td}>{record.studentName}</td>
                        <td style={styles.td}>{record.lesson}</td>
                        <td style={styles.td}>{record.date}</td>
                        <td style={styles.td}>
                          <span style={{ ...styles.badge, background: statusColors[record.status] }}>
                            {statusLabels[record.status]}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </section>
      </section>
    </main>
  );
}

function Card({ title, value, color }: { title: string; value: number | string; color: string }) {
  return (
    <div style={styles.card}>
      <div style={{ ...styles.cardValue, color }}>{value}</div>
      <div style={styles.cardTitle}>{title}</div>
    </div>
  );
}

function ChartBar({ label, value, total, color }: { label: string; value: number; total: number; color: string }) {
  const percent = total ? Math.round((value / total) * 100) : 0;

  return (
    <div style={styles.chartRow}>
      <div style={styles.chartText}>
        <span>{label}</span>
        <b>{value} ({percent}%)</b>
      </div>
      <div style={styles.barTrack}>
        <div style={{ ...styles.barFill, width: `${percent}%`, background: color }} />
      </div>
    </div>
  );
}

function StudentLine({ name, desc, value, tone }: { name: string; desc: string; value: string; tone: "danger" | "warning" | "success" }) {
  const color = tone === "danger" ? "#dc2626" : tone === "warning" ? "#f59e0b" : "#16a34a";

  return (
    <div style={styles.studentLine}>
      <div>
        <b style={styles.studentName}>{name}</b>
        <p style={styles.studentDesc}>{desc}</p>
      </div>
      <span style={{ ...styles.smallPill, background: `${color}18`, color }}>
        {value}
      </span>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#f4f7fb", direction: "rtl", padding: 24, fontFamily: "Tahoma, Arial, sans-serif", color: "#0f172a" },
  container: { maxWidth: 1180, margin: "0 auto" },
  header: { display: "flex", justifyContent: "space-between", gap: 16, marginBottom: 18 },
  path: { margin: 0, color: "#64748b", fontSize: 13 },
  title: { margin: "6px 0", fontSize: 32, fontWeight: 900 },
  subtitle: { margin: 0, color: "#64748b" },
  back: { background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: "12px 18px", color: "#0f172a", textDecoration: "none", fontWeight: 800, height: "fit-content" },
  filtersCard: { background: "#fff", borderRadius: 22, padding: 16, marginBottom: 16, border: "1px solid #e5e7eb", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 12, alignItems: "end" },
  label: { display: "block", marginBottom: 6, fontSize: 13, color: "#334155", fontWeight: 800 },
  input: { width: "100%", boxSizing: "border-box", padding: "12px 14px", borderRadius: 14, border: "1px solid #cbd5e1", color: "#111827", background: "#fff", fontSize: 14, outline: "none" },
  actionButton: { border: "none", borderRadius: 14, color: "#fff", padding: "12px 16px", cursor: "pointer", fontWeight: 900 },
  stats: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: 16 },
  card: { background: "#fff", borderRadius: 18, padding: 16, textAlign: "center", border: "1px solid #e5e7eb", boxShadow: "0 10px 24px rgba(15,23,42,0.06)" },
  cardValue: { fontSize: 30, fontWeight: 900 },
  cardTitle: { color: "#64748b", marginTop: 4, fontSize: 13 },
  grid2: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 16, marginBottom: 16 },
  panel: { background: "#fff", borderRadius: 22, padding: 18, border: "1px solid #e5e7eb", boxShadow: "0 10px 24px rgba(15,23,42,0.06)" },
  panelHeader: { display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", marginBottom: 14 },
  sectionTitle: { margin: 0, fontSize: 20, fontWeight: 900 },
  hint: { color: "#64748b", fontSize: 12, fontWeight: 800 },
  chartRow: { marginBottom: 14 },
  chartText: { display: "flex", justifyContent: "space-between", gap: 12, marginBottom: 7, color: "#334155", fontSize: 13 },
  barTrack: { height: 12, background: "#e5e7eb", borderRadius: 999, overflow: "hidden" },
  barFill: { height: "100%", borderRadius: 999 },
  list: { display: "grid", gap: 10 },
  studentLine: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, background: "#f8fafc", borderRadius: 14, padding: 12 },
  studentName: { color: "#0f172a", fontSize: 14 },
  studentDesc: { margin: "4px 0 0", color: "#64748b", fontSize: 12 },
  smallPill: { padding: "7px 10px", borderRadius: 999, fontSize: 12, fontWeight: 900, whiteSpace: "nowrap" },
  tableWrapper: { overflowX: "auto" },
  table: { width: "100%", minWidth: 520, borderCollapse: "collapse" },
  headRow: { background: "#f0fdf4" },
  th: { padding: 12, color: "#14532d", fontWeight: 900, borderBottom: "1px solid #dcfce7", textAlign: "center", fontSize: 13 },
  td: { padding: 12, borderBottom: "1px solid #f1f5f9", textAlign: "center", color: "#111827", fontSize: 13 },
  badge: { color: "#fff", padding: "6px 10px", borderRadius: 999, fontSize: 12, fontWeight: 900, display: "inline-block" },
  empty: { padding: 24, textAlign: "center", color: "#64748b" },
};
