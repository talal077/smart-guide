"use client";

import {useEffect,useState} from "react";
import Link from "next/link";
import {createClient} from "@/lib/supabase";

const supabase=createClient();

export default function AuditLogPage(){
 const [logs,setLogs]=useState<any[]>([]);
 useEffect(()=>{(async()=>{
   const {data}=await supabase.from("audit_logs").select("*").order("created_at",{ascending:false}).limit(100);
   setLogs(data||[]);
 })()},[]);
 return (
 <main style={{padding:24,direction:"rtl",background:"#f4f7fb",minHeight:"100vh",fontFamily:"Tahoma"}}>
  <div style={{maxWidth:1000,margin:"auto",background:"#fff",padding:24,borderRadius:18}}>
   <h1>سجل العمليات</h1>
   <table style={{width:"100%",borderCollapse:"collapse"}}>
    <thead><tr><th>المستخدم</th><th>العملية</th><th>الوقت</th></tr></thead>
    <tbody>
    {logs.map((l,i)=><tr key={i}>
      <td>{l.user_name||"-"}</td>
      <td>{l.action||"-"}</td>
      <td>{l.created_at||"-"}</td>
    </tr>)}
    </tbody>
   </table>
   <div style={{marginTop:20}}><Link href="/dashboard">العودة</Link></div>
  </div>
 </main>);
}
