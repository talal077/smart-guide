// Full replacement for src/app/noor-import/page.tsx
"use client";

import { useState } from "react";
import * as XLSX from "xlsx";
import { createClient } from "@/lib/supabase";

const supabase = createClient();

type NoorStudent={
  name:string;
  grade:string;
  section:string;
  nationalId:string;
};

export default function NoorImportPage(){
  const [file,setFile]=useState<File|null>(null);
  const [rows,setRows]=useState<NoorStudent[]>([]);
  const [msg,setMsg]=useState("");
  const [loading,setLoading]=useState(false);

  async function handleImport(){
    if(!file){setMsg("اختر ملف Excel.");return;}
    setLoading(true);
    try{
      const wb=XLSX.read(await file.arrayBuffer());
      const sheet=wb.Sheets[wb.SheetNames[0]];
      const data:any[]=XLSX.utils.sheet_to_json(sheet,{defval:""});
      const parsed=data.map(r=>({
        name:r["اسم الطالب"]||r["الاسم"]||"",
        grade:r["الصف"]||"",
        section:r["الفصل"]||r["الشعبة"]||"",
        nationalId:String(r["رقم الهوية"]||r["السجل المدني"]||"")
      })).filter(s=>s.name);
      setRows(parsed);

      let inserted=0;
      for(const s of parsed){
        const {data:exists}=await supabase.from("students")
          .select("id").eq("name",s.name).eq("grade",s.grade).eq("section",s.section).maybeSingle();
        if(exists) continue;
        const {error}=await supabase.from("students").insert({
          name:s.name,grade:s.grade,section:s.section,entry_code:s.nationalId
        });
        if(!error) inserted++;
      }
      setMsg(`تمت قراءة ${parsed.length} طالب، وتمت إضافة ${inserted}.`);
    }catch(e:any){
      setMsg("فشل قراءة الملف: "+e.message);
    }
    setLoading(false)
  }

  return (
    <main style={{padding:24,direction:"rtl",fontFamily:"Tahoma",background:"#f4f7fb",minHeight:"100vh"}}>
      <div style={{maxWidth:900,margin:"auto",background:"#fff",padding:24,borderRadius:18}}>
        <h1>استيراد طلاب نظام نور</h1>
        <input type="file" accept=".xlsx,.xls,.csv" onChange={e=>setFile(e.target.files?.[0]??null)} />
        <button onClick={handleImport} disabled={loading} style={{marginInlineStart:12,padding:"10px 18px"}}>
          {loading?"جارٍ الاستيراد...":"استيراد"}
        </button>
        <p>{msg}</p>
        {rows.length>0&&<table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead><tr><th>الاسم</th><th>الصف</th><th>الشعبة</th><th>الهوية</th></tr></thead>
          <tbody>
          {rows.map((r,i)=><tr key={i}><td>{r.name}</td><td>{r.grade}</td><td>{r.section}</td><td>{r.nationalId}</td></tr>)}
          </tbody>
        </table>}
      </div>
    </main>
  );
}
