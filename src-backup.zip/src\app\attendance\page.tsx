﻿"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  type AttendanceRecord,
  type StudentRecord,
  getAttendance,
  getSession,
  getStudents,
  saveAttendance,
} from "@/lib/appData";

type AttendanceStatus = AttendanceRecord["status"];

const statusLabels: Record<AttendanceStatus, string> = {
  present: "حاضر",
  absent: "غائب",
  late: "متأخر",
  excused: "مستأذن",
};

const statusColors: Record<AttendanceStatus, string> = {
  present: "#16a34a",
  absent: "#dc2626",
  late: "#f59e0b",
  excused: "#2563eb",
};

function todayIso() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export default function AttendancePage() {
  const router = useRouter();

  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [allRecords, setAllRecords] = useState<AttendanceRecord[]>([]);
  const [lesson, setLesson] = useState("الحصة الأولى");
  const [grade, setGrade] = useState("all");
  const [section, setSection] = useState("all");
  const [date, setDate] = useState(todayIso());
  const [teacherName, setTeacherName] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = getSession();
    if (!session) {
      router.replace("/login");
      return;
    }

    setTeacherName(session.name);
  }, [router]);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [studentData, attendanceData] = await Promise.all([
        getStudents(),
        getAttendance(),
      ]);
      setStudents(studentData);
      setAllRecords(attendanceData);
      setLoading(false);
    }

    load();
  }, []);

  const grades = useMemo(() => {
    return Array.from(new Set(students.map((student) => student.grade))).filter(Boolean);
  }, [students]);

  const sections = useMemo(() => {
    return Array.from(new Set(students.map((student) => student.section))).filter(Boolean);
  }, [students]);

  const visibleStudents = useMemo(() => {
    return students.filter((student) => {
      const gradeOk = grade === "all" || student.grade === grade;
      const sectionOk = section === "all" || student.section === section;
      return gradeOk && sectionOk;
    });
  }, [students, grade, section]);

  const attendanceMap = useMemo(() => {
    const map = new Map<string, AttendanceRecord>();

    for (const record of allRecords) {
      if (record.date === date && record.lesson === lesson) {
        map.set(record.studentId, record);
      }
    }

    return map;
  }, [allRecords, date, lesson]);

  const stats = useMemo(() => {
    const current = visibleStudents.map((student) => attendanceMap.get(student.id)?.status ?? "present");

    return {
      total: visibleStudents.length,
      present: current.filter((status) => status === "present").length,
      absent: current.filter((status) => status === "absent").length,
      late: current.filter((status) => status === "late").length,
      excused: current.filter((status) => status === "excused").length,
    };
  }, [visibleStudents, attendanceMap]);

  function buildRecord(student: StudentRecord, status: AttendanceStatus): AttendanceRecord {
    const existing = attendanceMap.get(student.id);

    return {
      id: existing?.id ?? `attendance-${student.id}-${date}-${lesson}`,
      studentId: student.id,
      studentName: student.name,
      grade: student.grade,
      section: student.section,
      date,
      lesson,
      status,
      updatedAt: new Date().toISOString(),
    };
  }

  function setStudentStatus(student: StudentRecord, status: AttendanceStatus) {
    const nextRecord = buildRecord(student, status);

    setAllRecords((prev) => {
      const withoutCurrent = prev.filter((record) => record.id !== nextRecord.id);
      return [nextRecord, ...withoutCurrent];
    });
  }

  function markAllPresent() {
    const nextRecords = visibleStudents.map((student) => buildRecord(student, "present"));

    setAllRecords((prev) => {
      const keys = new Set(nextRecords.map((record) => record.id));
      return [...nextRecords, ...prev.filter((record) => !keys.has(record.id))];
    });

    setMessage("تم اعتبار جميع الطلاب حاضرين.");
  }

  function updateAbsencesOnly() {
    const nextRecords = visibleStudents.map((student) => {
      const current = attendanceMap.get(student.id);
      return buildRecord(student, current?.status === "absent" ? "absent" : "present");
    });

    setAllRecords((prev) => {
      const keys = new Set(nextRecords.map((record) => record.id));
      return [...nextRecords, ...prev.filter((record) => !keys.has(record.id))];
    });

    setMessage("تم تحديث الغياب فقط.");
  }

  function copyPreviousLesson() {
    const lessonOrder = [
      "الحصة الأولى",
      "الحصة الثانية",
      "الحصة الثالثة",
      "الحصة الرابعة",
      "الحصة الخامسة",
      "الحصة السادسة",
      "الحصة السابعة",
    ];

    const currentIndex = lessonOrder.indexOf(lesson);
    if (currentIndex <= 0) {
      setMessage("لا توجد حصة سابقة لهذه الحصة.");
      return;
    }

    const previousLesson = lessonOrder[currentIndex - 1];
    const copied = visibleStudents.map((student) => {
      const previous = allRecords.find(
        (record) =>
          record.studentId === student.id &&
          record.date === date &&
          record.lesson === previousLesson
      );

      return buildRecord(student, previous?.status ?? "present");
    });

    setAllRecords((prev) => {
      const keys = new Set(copied.map((record) => record.id));
      return [...copied, ...prev.filter((record) => !keys.has(record.id))];
    });

    setMessage("تم نسخ التحضير من الحصة السابقة.");
  }

  async function saveCurrentAttendance() {
    const currentRecords = visibleStudents.map((student) => {
      const status = attendanceMap.get(student.id)?.status ?? "present";
      return buildRecord(student, status);
    });

    const keys = new Set(currentRecords.map((record) => record.id));
    const nextAllRecords = [
      ...currentRecords,
      ...allRecords.filter((record) => !keys.has(record.id)),
    ];

    setAllRecords(nextAllRecords);
    await saveAttendance(nextAllRecords);
    setMessage("تم حفظ التحضير في قاعدة البيانات.");
  }

  async function submitToVicePrincipal() {
    await saveCurrentAttendance();
    setMessage("تم حفظ التحضير وإرساله للوكيل/الإداري.");
  }

  return (
    <main style={styles.page}>
      <section style={styles.container}>
        <header style={styles.header}>
          <div>
            <p style={styles.path}>الرئيسية / تحضير الحصص</p>
            <h1 style={styles.title}>تحضير الحصص</h1>
            <p style={styles.subtitle}>
              تسجيل حضور الطلاب للحصة المحددة وحفظه مباشرة في قاعدة البيانات.
            </p>
          </div>

          <Link href="/dashboard" style={styles.back}>
            العودة
          </Link>
        </header>

        <section style={styles.infoCard}>
          <div>
            <span style={styles.infoLabel}>التاريخ</span>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={styles.input} />
          </div>

          <div>
            <span style={styles.infoLabel}>الحصة</span>
            <select value={lesson} onChange={(e) => setLesson(e.target.value)} style={styles.input}>
              <option value="الحصة الأولى">الحصة الأولى</option>
              <option value="الحصة الثانية">الحصة الثانية</option>
              <option value="الحصة الثالثة">الحصة الثالثة</option>
              <option value="الحصة الرابعة">الحصة الرابعة</option>
              <option value="الحصة الخامسة">الحصة الخامسة</option>
              <option value="الحصة السادسة">الحصة السادسة</option>
              <option value="الحصة السابعة">الحصة السابعة</option>
            </select>
          </div>

          <div>
            <span style={styles.infoLabel}>الصف</span>
            <select value={grade} onChange={(e) => setGrade(e.target.value)} style={styles.input}>
              <option value="all">كل الصفوف</option>
              {grades.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>

          <div>
            <span style={styles.infoLabel}>الشعبة</span>
            <select value={section} onChange={(e) => setSection(e.target.value)} style={styles.input}>
              <option value="all">كل الشعب</option>
              {sections.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>

          <div>
            <span style={styles.infoLabel}>المعلم</span>
            <input value={teacherName} onChange={(e) => setTeacherName(e.target.value)} style={styles.input} />
          </div>
        </section>

        <section style={styles.stats}>
          <Stat title="إجمالي الطلاب" value={stats.total} color="#0f172a" />
          <Stat title="حاضر" value={stats.present} color="#16a34a" />
          <Stat title="غائب" value={stats.absent} color="#dc2626" />
          <Stat title="متأخر" value={stats.late} color="#f59e0b" />
          <Stat title="مستأذن" value={stats.excused} color="#2563eb" />
        </section>

        <section style={styles.actionsCard}>
          <button onClick={markAllPresent} style={{ ...styles.actionButton, background: "#16a34a" }}>
            اعتبار جميع الطلاب حاضرين
          </button>
          <button onClick={copyPreviousLesson} style={{ ...styles.actionButton, background: "#2563eb" }}>
            نسخ من الحصة السابقة
          </button>
          <button onClick={updateAbsencesOnly} style={{ ...styles.actionButton, background: "#f59e0b" }}>
            تحديث الغياب فقط
          </button>
          <button onClick={saveCurrentAttendance} style={{ ...styles.actionButton, background: "#0f766e" }}>
            حفظ التحضير
          </button>
          <button onClick={submitToVicePrincipal} style={{ ...styles.actionButton, background: "#7c3aed" }}>
            إرسال للوكيل/الإداري
          </button>
        </section>

        {message ? <p style={styles.message}>{message}</p> : null}

        <section style={styles.tableCard}>
          <div style={styles.tableHeader}>
            <h2 style={styles.sectionTitle}>قائمة الطلاب</h2>
            <span style={styles.count}>{visibleStudents.length} طالب</span>
          </div>

          {loading ? (
            <div style={styles.empty}>جارٍ تحميل بيانات الطلاب...</div>
          ) : visibleStudents.length === 0 ? (
            <div style={styles.empty}>لا يوجد طلاب في هذا الصف/الشعبة.</div>
          ) : (
            <div style={styles.tableWrapper}>
              <table style={styles.table}>
                <thead>
                  <tr style={styles.headRow}>
                    <th style={styles.th}>#</th>
                    <th style={styles.th}>اسم الطالب</th>
                    <th style={styles.th}>الصف</th>
                    <th style={styles.th}>الشعبة</th>
                    <th style={styles.th}>الحالة</th>
                    <th style={styles.th}>الإجراءات</th>
                  </tr>
                </thead>

                <tbody>
                  {visibleStudents.map((student, index) => {
                    const status = attendanceMap.get(student.id)?.status ?? "present";

                    return (
                      <tr key={student.id}>
                        <td style={styles.td}>{index + 1}</td>
                        <td style={{ ...styles.td, fontWeight: 900, color: "#000" }}>{student.name}</td>
                        <td style={styles.td}>{student.grade}</td>
                        <td style={styles.td}>{student.section}</td>
                        <td style={styles.td}>
                          <span style={{ ...styles.badge, background: statusColors[status] }}>
                            {statusLabels[status]}
                          </span>
                        </td>
                        <td style={styles.td}>
                          <div style={styles.statusButtons}>
                            {(Object.keys(statusLabels) as AttendanceStatus[]).map((item) => (
                              <button
                                key={item}
                                onClick={() => setStudentStatus(student, item)}
                                style={{
                                  ...styles.statusButton,
                                  borderColor: statusColors[item],
                                  background: status === item ? statusColors[item] : "#fff",
                                  color: status === item ? "#fff" : statusColors[item],
                                }}
                              >
                                {statusLabels[item]}
                              </button>
                            ))}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </section>
    </main>
  );
}

function Stat({ title, value, color }: { title: string; value: number; color: string }) {
  return (
    <div style={styles.statCard}>
      <div style={{ ...styles.statValue, color }}>{value}</div>
      <div style={styles.statTitle}>{title}</div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#f4f7fb", direction: "rtl", padding: 24, fontFamily: "Tahoma, Arial, sans-serif", color: "#0f172a" },
  container: { maxWidth: 1180, margin: "0 auto" },
  header: { display: "flex", justifyContent: "space-between", gap: 16, marginBottom: 18 },
  path: { margin: 0, color: "#64748b", fontSize: 13 },
  title: { margin: "6px 0", fontSize: 32, fontWeight: 900 },
  subtitle: { margin: 0, color: "#64748b" },
  back: { background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: "12px 18px", color: "#0f172a", textDecoration: "none", fontWeight: 800, height: "fit-content" },
  infoCard: { background: "#fff", borderRadius: 22, padding: 16, marginBottom: 16, border: "1px solid #e5e7eb", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 12 },
  infoLabel: { display: "block", marginBottom: 6, fontSize: 13, color: "#334155", fontWeight: 800 },
  input: { width: "100%", boxSizing: "border-box", padding: "12px 14px", borderRadius: 14, border: "1px solid #cbd5e1", color: "#111827", background: "#fff", fontSize: 14, outline: "none" },
  stats: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: 16 },
  statCard: { background: "#fff", borderRadius: 18, padding: 16, textAlign: "center", border: "1px solid #e5e7eb", boxShadow: "0 10px 24px rgba(15,23,42,0.06)" },
  statValue: { fontSize: 30, fontWeight: 900 },
  statTitle: { color: "#64748b", marginTop: 4, fontSize: 13 },
  actionsCard: { background: "#fff", borderRadius: 22, padding: 16, marginBottom: 12, border: "1px solid #e5e7eb", display: "flex", flexWrap: "wrap", gap: 10 },
  actionButton: { border: "none", borderRadius: 14, color: "#fff", padding: "12px 16px", cursor: "pointer", fontWeight: 900 },
  message: { margin: "0 0 12px", color: "#0f766e", fontWeight: 900, background: "#ecfdf5", padding: 12, borderRadius: 14 },
  tableCard: { background: "#fff", borderRadius: 22, border: "1px solid #e5e7eb", overflow: "hidden" },
  tableHeader: { padding: 18, borderBottom: "1px solid #e5e7eb", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" },
  sectionTitle: { margin: 0, fontSize: 20, fontWeight: 900 },
  count: { background: "#e0f2fe", color: "#0369a1", padding: "7px 12px", borderRadius: 999, fontWeight: 900, fontSize: 12 },
  tableWrapper: { overflowX: "auto" },
  table: { width: "100%", minWidth: 860, borderCollapse: "collapse" },
  headRow: { background: "#f0fdf4" },
  th: { padding: 14, color: "#14532d", fontWeight: 900, borderBottom: "1px solid #dcfce7", textAlign: "center" },
  td: { padding: 14, borderBottom: "1px solid #f1f5f9", textAlign: "center", color: "#111827" },
  badge: { color: "#fff", padding: "7px 12px", borderRadius: 999, fontSize: 12, fontWeight: 900, display: "inline-block" },
  statusButtons: { display: "flex", justifyContent: "center", gap: 8, flexWrap: "wrap" },
  statusButton: { border: "1px solid", borderRadius: 10, padding: "8px 10px", cursor: "pointer", fontWeight: 900, minWidth: 68 },
  empty: { padding: 28, textAlign: "center", color: "#64748b" },
};
