"use client";
import Link from "next/link";
export default function TeacherAssignmentsPage(){
const rows=[{teacher:"أحمد علي",subject:"رياضيات",className:"1/أ"},{teacher:"محمد سالم",subject:"عربي",className:"2/أ"}];
return <main style={{padding:24,direction:"rtl",fontFamily:"Tahoma",background:"#f4f7fb",minHeight:"100vh"}}>
<div style={{maxWidth:900,margin:"auto"}}>
<div style={{display:"flex",justifyContent:"space-between"}}><h1>إسناد المعلمين</h1><Link href="/dashboard">العودة</Link></div>
<table style={{width:"100%",background:"#fff",borderCollapse:"collapse",marginTop:16}}>
<thead><tr><th>المعلم</th><th>المادة</th><th>الشعبة</th></tr></thead>
<tbody>{rows.map((r,i)=><tr key={i}><td style={td}>{r.teacher}</td><td style={td}>{r.subject}</td><td style={td}>{r.className}</td></tr>)}</tbody>
</table></div></main>}
const td={padding:"12px",borderBottom:"1px solid #ddd",textAlign:"center"} as const;
