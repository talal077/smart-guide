import { NextRequest, NextResponse } from "next/server";
import { canAccess } from "@/lib/permissions";

export function middleware(request: NextRequest) {
  const session = request.cookies.get("smart-guide-session");

  if (!session) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  try {
    const user = JSON.parse(session.value);

    if (!canAccess(user.role, request.nextUrl.pathname)) {
      return NextResponse.redirect(new URL("/dashboard", request.url));
    }

    return NextResponse.next();
  } catch {
    return NextResponse.redirect(new URL("/login", request.url));
  }
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/attendance/:path*",
    "/students/:path*",
    "/reports/:path*",
    "/notifications/:path*",
    "/operations-log/:path*",
    "/teachers/:path*",
    "/classes/:path*",
    "/subjects/:path*",
    "/settings/:path*",
    "/student-actions/:path*",
    "/admin/:path*",
    "/vice-principal/:path*",
  ],
};