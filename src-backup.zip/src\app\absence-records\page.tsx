"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  type AttendanceRecord,
  getAttendance,
  getSession,
  saveAttendance,
} from "@/lib/appData";

type Status = AttendanceRecord["status"];
type StatusFilter = "all" | Status;

const labels: Record<Status, string> = {
  present: "حاضر",
  absent: "غائب",
  late: "متأخر",
  excused: "مستأذن",
};

const colors: Record<Status, string> = {
  present: "#16a34a",
  absent: "#dc2626",
  late: "#f59e0b",
  excused: "#2563eb",
};

export default function AbsenceRecordsPage() {
  const router = useRouter();
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");

  useEffect(() => {
    const session = getSession();
    if (!session) router.replace("/login");
  }, [router]);

  useEffect(() => {
    async function load() {
      const data = await getAttendance();
      setRecords(data);
    }
    load();
  }, []);

  const filtered = useMemo(() => {
    return records.filter((r) => {
      const q = search.trim();

      const matchesSearch =
        !q ||
        r.studentName.includes(q) ||
        r.grade.includes(q) ||
        r.section.includes(q) ||
        r.lesson.includes(q) ||
        r.date.includes(q);

      const matchesStatus = statusFilter === "all" || r.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [records, search, statusFilter]);

  async function updateStatus(id: string, status: Status) {
    const next = records.map((record) =>
      record.id === id
        ? { ...record, status, updatedAt: new Date().toISOString() }
        : record
    );

    setRecords(next);
    await saveAttendance(next);
  }

  const stats = {
    total: records.length,
    present: records.filter((r) => r.status === "present").length,
    absent: records.filter((r) => r.status === "absent").length,
    late: records.filter((r) => r.status === "late").length,
    excused: records.filter((r) => r.status === "excused").length,
  };

  return (
    <main style={styles.page}>
      <section style={styles.container}>
        <header style={styles.header}>
          <div>
            <p style={styles.path}>الرئيسية / سجل الغياب</p>
            <h1 style={styles.title}>سجل الغياب</h1>
            <p style={styles.subtitle}>متابعة الحضور والغياب والتأخر والاستئذان.</p>
          </div>

          <Link href="/dashboard" style={styles.back}>
            العودة
          </Link>
        </header>

        <section style={styles.stats}>
          <Card title="الإجمالي" value={stats.total} color="#2563eb" />
          <Card title="حاضر" value={stats.present} color="#16a34a" />
          <Card title="غائب" value={stats.absent} color="#dc2626" />
          <Card title="متأخر" value={stats.late} color="#f59e0b" />
          <Card title="مستأذن" value={stats.excused} color="#2563eb" />
        </section>

        <section style={styles.filters}>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث باسم الطالب أو الصف أو الشعبة أو الحصة"
            style={styles.input}
          />

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
            style={styles.select}
          >
            <option value="all">كل الحالات</option>
            <option value="present">حاضر</option>
            <option value="absent">غائب</option>
            <option value="late">متأخر</option>
            <option value="excused">مستأذن</option>
          </select>
        </section>

        <section style={styles.tableCard}>
          <div style={styles.tableWrap}>
            <table style={styles.table}>
              <thead>
                <tr style={styles.headRow}>
                  <th style={styles.th}>#</th>
                  <th style={styles.th}>الطالب</th>
                  <th style={styles.th}>الصف</th>
                  <th style={styles.th}>الشعبة</th>
                  <th style={styles.th}>الحصة</th>
                  <th style={styles.th}>التاريخ</th>
                  <th style={styles.th}>الحالة</th>
                  <th style={styles.th}>تعديل</th>
                </tr>
              </thead>

              <tbody>
                {filtered.map((record, index) => (
                  <tr key={record.id}>
                    <td style={styles.td}>{index + 1}</td>
                    <td style={{ ...styles.td, fontWeight: 900 }}>{record.studentName}</td>
                    <td style={styles.td}>{record.grade}</td>
                    <td style={styles.td}>{record.section}</td>
                    <td style={styles.td}>{record.lesson}</td>
                    <td style={styles.td}>{record.date}</td>
                    <td style={styles.td}>
                      <span style={{ ...styles.badge, background: colors[record.status] }}>
                        {labels[record.status]}
                      </span>
                    </td>
                    <td style={styles.td}>
                      <div style={styles.actions}>
                        {(Object.keys(labels) as Status[]).map((status) => (
                          <button
                            key={status}
                            type="button"
                            onClick={() => updateStatus(record.id, status)}
                            style={{
                              ...styles.statusButton,
                              background:
                                record.status === status ? colors[status] : "#f1f5f9",
                              color: record.status === status ? "#fff" : "#334155",
                            }}
                          >
                            {labels[status]}
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filtered.length === 0 ? (
              <div style={styles.empty}>لا توجد سجلات.</div>
            ) : null}
          </div>
        </section>
      </section>
    </main>
  );
}

function Card({ title, value, color }: { title: string; value: number; color: string }) {
  return (
    <div style={styles.card}>
      <div style={{ ...styles.cardValue, color }}>{value}</div>
      <div style={styles.cardTitle}>{title}</div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: "100vh",
    background: "#f4f7fb",
    direction: "rtl",
    padding: 24,
    fontFamily: "Tahoma, Arial, sans-serif",
    color: "#0f172a",
  },
  container: {
    maxWidth: 1180,
    margin: "0 auto",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    gap: 16,
    marginBottom: 18,
  },
  path: {
    margin: 0,
    color: "#64748b",
    fontSize: 13,
  },
  title: {
    margin: "6px 0",
    fontSize: 32,
    fontWeight: 900,
  },
  subtitle: {
    margin: 0,
    color: "#64748b",
  },
  back: {
    background: "#fff",
    border: "1px solid #e2e8f0",
    borderRadius: 14,
    padding: "12px 18px",
    color: "#0f172a",
    textDecoration: "none",
    fontWeight: 800,
    height: "fit-content",
  },
  stats: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
    gap: 12,
    marginBottom: 16,
  },
  card: {
    background: "#fff",
    borderRadius: 18,
    padding: 16,
    textAlign: "center",
    border: "1px solid #e5e7eb",
  },
  cardValue: {
    fontSize: 30,
    fontWeight: 900,
  },
  cardTitle: {
    color: "#64748b",
    marginTop: 4,
    fontSize: 13,
  },
  filters: {
    background: "#fff",
    borderRadius: 20,
    padding: 16,
    display: "grid",
    gridTemplateColumns: "1fr 220px",
    gap: 12,
    marginBottom: 16,
    border: "1px solid #e5e7eb",
  },
  input: {
    padding: "12px 14px",
    borderRadius: 14,
    border: "1px solid #cbd5e1",
    fontSize: 14,
  },
  select: {
    padding: "12px 14px",
    borderRadius: 14,
    border: "1px solid #cbd5e1",
    fontSize: 14,
  },
  tableCard: {
    background: "#fff",
    borderRadius: 22,
    border: "1px solid #e5e7eb",
    overflow: "hidden",
  },
  tableWrap: {
    overflowX: "auto",
  },
  table: {
    width: "100%",
    minWidth: 900,
    borderCollapse: "collapse",
  },
  headRow: {
    background: "#f0fdf4",
  },
  th: {
    padding: 14,
    color: "#14532d",
    fontWeight: 900,
    borderBottom: "1px solid #dcfce7",
    textAlign: "center",
  },
  td: {
    padding: 14,
    borderBottom: "1px solid #f1f5f9",
    textAlign: "center",
    color: "#111827",
  },
  badge: {
    display: "inline-flex",
    color: "#fff",
    padding: "7px 12px",
    borderRadius: 999,
    fontWeight: 900,
    fontSize: 12,
  },
  actions: {
    display: "flex",
    gap: 8,
    justifyContent: "center",
    flexWrap: "wrap",
  },
  statusButton: {
    border: "none",
    borderRadius: 10,
    padding: "8px 12px",
    cursor: "pointer",
    fontWeight: 900,
  },
  empty: {
    padding: 28,
    textAlign: "center",
    color: "#64748b",
  },
};