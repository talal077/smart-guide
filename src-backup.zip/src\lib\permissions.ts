export type UserRole =
  | "admin"
  | "vice_principal"
  | "teacher"
  | "student";

export const permissions: Record<UserRole, string[]> = {
  admin: ["*"],

  vice_principal: [
    "/dashboard",
    "/attendance",
    "/students",
    "/reports",
    "/notifications",
    "/operations-log",
    "/teachers",
    "/classes",
    "/subjects",
    "/settings",
  ],

  teacher: [
    "/dashboard",
    "/attendance",
    "/reports",
    "/notifications",
    "/student-actions",
  ],

  student: [
    "/dashboard",
    "/attendance",
  ],
};

export function canAccess(role: UserRole, path: string) {
  const allowed = permissions[role];

  if (allowed.includes("*")) return true;

  return allowed.some((item) => path.startsWith(item));
}