export type AppRole =
  | "principal"
  | "teacher"
  | "vice_principal"
  | "admin"
  | "student";

export type AppSession = {
  id?: string;
  userId: string;
  name: string;
  email?: string;
  role: AppRole;
};

const SESSION_KEY = "smart-guide-session";

export function getSession(): AppSession | null {
  if (typeof window === "undefined") return null;

  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AppSession;
  } catch {
    return null;
  }
}

export function saveSession(session: AppSession) {
  if (typeof window === "undefined") return;

  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

export function clearSession() {
  if (typeof window === "undefined") return;

  localStorage.removeItem(SESSION_KEY);
}