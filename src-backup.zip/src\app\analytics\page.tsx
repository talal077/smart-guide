"use client";

import {
  AlertTriangle,
  BarChart3,
  CalendarDays,
  Download,
  FileDown,
  Medal,
  ShieldAlert,
  TrendingDown,
  TrendingUp,
  UserCheck,
  UserMinus,
  Users,
} from "lucide-react";

const overview = [
  { title: "إجمالي الطلاب", value: 482, note: "جميع الصفوف", icon: Users },
  { title: "حاضرون اليوم", value: 438, note: "91% حضور", icon: UserCheck },
  { title: "غائبون", value: 31, note: "إجمالي الغياب", icon: UserMinus },
  { title: "بعذر", value: 12, note: "أعذار معتمدة", icon: ShieldAlert },
  { title: "بدون عذر", value: 19, note: "تحتاج متابعة", icon: AlertTriangle },
  { title: "متأخرون", value: 13, note: "حالات تأخر", icon: TrendingDown },
];

const weeklyAbsence = [
  { day: "الأحد", value: 18 },
  { day: "الاثنين", value: 22 },
  { day: "الثلاثاء", value: 31 },
  { day: "الأربعاء", value: 26 },
  { day: "الخميس", value: 19 },
];

const gradeComparison = [
  { grade: "الأول الثانوي", total: 160, present: 149, absent: 11, rate: 93 },
  { grade: "الثاني الثانوي", total: 158, present: 142, absent: 16, rate: 90 },
  { grade: "الثالث الثانوي", total: 164, present: 147, absent: 17, rate: 89 },
];

const topAbsentStudents = [
  { name: "خالد أحمد الحربي", className: "أول / أ", count: 7, risk: "مرتفع" },
  { name: "سعد محمد الجهني", className: "ثاني / ب", count: 5, risk: "متوسط" },
  { name: "تركي ناصر المطيري", className: "ثالث / ج", count: 4, risk: "متوسط" },
];

const committedStudents = [
  { name: "باسل فهد الحربي", className: "ثالث / ب", rate: "100%" },
  { name: "ريان سامي البلوي", className: "أول / أ", rate: "99%" },
  { name: "يزيد عبدالله العوفي", className: "ثاني / أ", rate: "98%" },
];

const teacherCommitment = [
  { teacher: "أ. عبدالله الحربي", submitted: 24, total: 24, rate: 100 },
  { teacher: "أ. محمد السلمي", submitted: 22, total: 24, rate: 92 },
  { teacher: "أ. فهد العوفي", submitted: 21, total: 24, rate: 88 },
];

const riskLevels = [
  { title: "منخفض", value: 43, className: "bg-green-100 text-green-700" },
  { title: "متوسط", value: 21, className: "bg-yellow-100 text-yellow-700" },
  { title: "مرتفع", value: 8, className: "bg-red-100 text-red-700" },
  { title: "حرج", value: 3, className: "bg-slate-900 text-white" },
];

export default function AnalyticsPage() {
  return (
    <section className="px-4 py-5">
      <div className="mx-auto max-w-7xl space-y-5">
        <header className="rounded-3xl bg-white p-5 shadow-sm border border-slate-100">
          <p className="text-sm font-bold text-blue-700">التحليلات والإحصائيات</p>
          <h1 className="mt-1 text-2xl font-bold text-slate-900">
            مركز تحليل الحضور والانضباط
          </h1>
          <p className="mt-2 text-sm text-slate-500">
            قراءة تحليلية لمؤشرات الحضور والغياب، مقارنة الصفوف، التزام المعلمين، ومؤشر الخطورة.
          </p>
        </header>

        <section className="rounded-3xl bg-white p-4 shadow-sm border border-slate-100">
          <div className="grid gap-3 md:grid-cols-4">
            <select className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm outline-none focus:border-blue-500">
              <option>اليوم</option>
              <option>هذا الأسبوع</option>
              <option>هذا الشهر</option>
              <option>هذا الفصل</option>
            </select>

            <button className="flex items-center justify-center gap-2 rounded-2xl bg-blue-700 px-4 py-3 text-sm font-bold text-white">
              <CalendarDays size={18} />
              تحديث التحليل
            </button>

            <button className="flex items-center justify-center gap-2 rounded-2xl bg-slate-100 px-4 py-3 text-sm font-bold text-slate-700">
              <FileDown size={18} />
              Excel
            </button>

            <button className="flex items-center justify-center gap-2 rounded-2xl bg-slate-100 px-4 py-3 text-sm font-bold text-slate-700">
              <Download size={18} />
              PDF
            </button>
          </div>
        </section>

        <section className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
          {overview.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="rounded-3xl bg-white p-4 shadow-sm border border-slate-100"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm text-slate-500">{item.title}</p>
                    <h2 className="mt-2 text-3xl font-black text-slate-900">
                      {item.value}
                    </h2>
                    <p className="mt-1 text-xs text-slate-400">{item.note}</p>
                  </div>

                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-700">
                    <Icon size={22} />
                  </div>
                </div>
              </div>
            );
          })}
        </section>

        <section className="grid gap-4 xl:grid-cols-3">
          <Card title="الغياب الأسبوعي" icon={<BarChart3 size={20} />}>
            <div className="space-y-4">
              {weeklyAbsence.map((item) => {
                const percent = Math.min(100, Math.round((item.value / 40) * 100));

                return (
                  <div key={item.day} className="rounded-2xl bg-slate-50 p-4">
                    <div className="mb-2 flex items-center justify-between">
                      <h3 className="font-bold text-slate-900">{item.day}</h3>
                      <span className="text-sm font-bold text-blue-700">
                        {item.value} غياب
                      </span>
                    </div>

                    <div className="h-2 overflow-hidden rounded-full bg-slate-200">
                      <div
                        className="h-full rounded-full bg-blue-700"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          <Card title="مؤشر الخطورة" icon={<ShieldAlert size={20} />}>
            <div className="grid grid-cols-2 gap-3">
              {riskLevels.map((item) => (
                <div key={item.title} className="rounded-2xl bg-slate-50 p-4 text-center">
                  <span className={`rounded-full px-3 py-1 text-xs font-bold ${item.className}`}>
                    {item.title}
                  </span>
                  <h3 className="mt-3 text-3xl font-black text-slate-900">{item.value}</h3>
                  <p className="mt-1 text-xs text-slate-500">طالب</p>
                </div>
              ))}
            </div>
          </Card>

          <Card title="القراءة التحليلية" icon={<TrendingUp size={20} />}>
            <div className="space-y-3">
              <Insight
                title="ارتفاع الحضور"
                detail="نسبة الحضور اليوم 91%، وهي أعلى من متوسط الأسبوع الماضي بثلاث نقاط."
              />
              <Insight
                title="تنبيه مهم"
                detail="الصف الثالث الثانوي لديه أعلى معدل غياب ويحتاج متابعة من الوكيل."
              />
              <Insight
                title="توصية"
                detail="ابدأ بمراجعة الطلاب ذوي الخطورة المرتفعة والحرجة قبل نهاية الأسبوع."
              />
            </div>
          </Card>
        </section>

        <section className="grid gap-4 xl:grid-cols-2">
          <Card title="مقارنة الصفوف" icon={<Users size={20} />}>
            <div className="space-y-3">
              {gradeComparison.map((item) => (
                <div key={item.grade} className="rounded-2xl bg-slate-50 p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <h3 className="font-bold text-slate-900">{item.grade}</h3>
                    <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-bold text-blue-700">
                      {item.rate}%
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-sm">
                    <Mini title="الإجمالي" value={item.total} />
                    <Mini title="حاضر" value={item.present} />
                    <Mini title="غائب" value={item.absent} />
                  </div>

                  <div className="mt-4 h-2 overflow-hidden rounded-full bg-slate-200">
                    <div
                      className="h-full rounded-full bg-blue-700"
                      style={{ width: `${item.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card title="التزام المعلمين برفع التحضير" icon={<Medal size={20} />}>
            <div className="space-y-3">
              {teacherCommitment.map((item) => (
                <div key={item.teacher} className="rounded-2xl bg-slate-50 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="font-bold text-slate-900">{item.teacher}</h3>
                    <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-bold text-green-700">
                      {item.rate}%
                    </span>
                  </div>

                  <p className="text-sm text-slate-500">
                    رفع {item.submitted} من أصل {item.total} حصة
                  </p>

                  <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-200">
                    <div
                      className="h-full rounded-full bg-green-600"
                      style={{ width: `${item.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </section>

        <section className="grid gap-4 xl:grid-cols-2">
          <Card title="أكثر الطلاب غيابًا" icon={<UserMinus size={20} />}>
            <div className="space-y-3">
              {topAbsentStudents.map((student) => (
                <div
                  key={student.name}
                  className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 p-4"
                >
                  <div>
                    <p className="font-bold text-slate-900">{student.name}</p>
                    <p className="mt-1 text-xs text-slate-500">{student.className}</p>
                  </div>
                  <div className="text-left">
                    <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-700">
                      {student.count} أيام
                    </span>
                    <p className="mt-2 text-xs text-slate-500">{student.risk}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card title="أكثر الطلاب التزامًا" icon={<UserCheck size={20} />}>
            <div className="space-y-3">
              {committedStudents.map((student) => (
                <div
                  key={student.name}
                  className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 p-4"
                >
                  <div>
                    <p className="font-bold text-slate-900">{student.name}</p>
                    <p className="mt-1 text-xs text-slate-500">{student.className}</p>
                  </div>
                  <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-bold text-green-700">
                    {student.rate}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </section>

        <section className="rounded-3xl border border-blue-100 bg-blue-50 p-5">
          <h2 className="font-bold text-blue-900">ملاحظة تشغيلية</h2>
          <p className="mt-2 text-sm text-blue-800">
            عند ربط Supabase سيتم احتساب هذه المؤشرات مباشرة من سجلات التحضير، الطلاب، الشعب، الأعذار، وسجل عدم الرفع.
          </p>
        </section>
      </div>
    </section>
  );
}

function Card({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-3xl bg-white p-4 shadow-sm border border-slate-100">
      <div className="mb-4 flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-blue-50 text-blue-700">
          {icon}
        </div>
        <h2 className="font-bold text-slate-900">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function Mini({ title, value }: { title: string; value: number }) {
  return (
    <div className="rounded-2xl bg-white p-3">
      <p className="text-xs text-slate-500">{title}</p>
      <h4 className="mt-1 text-lg font-black text-slate-900">{value}</h4>
    </div>
  );
}

function Insight({ title, detail }: { title: string; detail: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-4">
      <h3 className="font-bold text-slate-900">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-slate-500">{detail}</p>
    </div>
  );
}
